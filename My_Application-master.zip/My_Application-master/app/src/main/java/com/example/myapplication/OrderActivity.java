package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.os.CountDownTimer;
import android.util.Log;
import android.widget.TextView;

import com.parse.FindCallback;
import com.parse.ParseException;
import com.parse.ParseQuery;

import java.util.ArrayList;
import java.util.List;

public class OrderActivity extends AppCompatActivity {

    private double totalCost;
    private TextView tvTotalCost;
    private RecyclerView rvCheckoutList;
    private orderAdapter adapter;
    private CountDownTimer countDownTimer;
    public static ArrayList<CheckoutList> cartItemList = new ArrayList<>();
    public static final String TAG = "Order ACTIVITY";



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order);
        tvTotalCost = findViewById(R.id.tvTotalCost);
        rvCheckoutList = findViewById(R.id.rvCheckoutList);
        totalCost = 0;
        adapter = new orderAdapter(this, cartItemList);
        rvCheckoutList.setAdapter(adapter);
        rvCheckoutList.setLayoutManager(new LinearLayoutManager(this));
        queryPosts();
        refreshView();
    }

    private void queryPosts() {
        ParseQuery<CheckoutList> query = ParseQuery.getQuery(CheckoutList.class);
        query.findInBackground(new FindCallback<CheckoutList>() {
            @Override
            public void done(List<CheckoutList> items, ParseException e) {
                if (e != null){
                    Log.e(TAG, "Issue with getting posts", e);
                    return;
                }
                for (CheckoutList item: items){
                    Log.i(TAG, "item:" + item.getItem());
                }
                cartItemList.addAll(items);
                adapter.notifyDataSetChanged();
            }
        });
    }

    public void refreshView() {
        countDownTimer = new CountDownTimer(10000, 1000) {
            @Override
            public void onTick(long l) {

            }

            @Override
            public void onFinish() {
                System.out.println("finish timer");
                cartItemList.clear();
                queryPosts();
                adapter.notifyDataSetChanged();
                refreshView();
            }
        }.start();
    }
}